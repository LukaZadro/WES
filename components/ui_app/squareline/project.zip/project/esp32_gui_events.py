
def dark_mode_on(event_struct):
    return


def dark_mode_off(event_struct):
    return

